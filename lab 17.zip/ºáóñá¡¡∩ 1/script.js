// 1) Нове вікно розміром 300х300 пікселів
var newWindow = window.open('', '', 'width=300,height=300');

// 2) Зміна розмірів вікна після затримки 2 секунд
setTimeout(function() {
  newWindow.resizeTo(500, 500);
}, 2000);

// 3) Переміщення вікна в точку з координатами (200, 200) після затримки 2 секунд
setTimeout(function() {
  newWindow.moveTo(200, 200);
}, 4000);

// 4) Закриття вікна після затримки 2 секунд
setTimeout(function() {
  newWindow.close();
}, 6000);
