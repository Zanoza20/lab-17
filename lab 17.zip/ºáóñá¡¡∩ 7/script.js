var countrySelect = document.getElementById('country');
var citiesSelect = document.getElementById('cities');
var result = document.querySelector('p');

countrySelect.addEventListener('change', function() {
  var country = countrySelect.value;
  var cities;

  if (country === 'ger') {
    cities = ['Berlin', 'Munich', 'Hamburg'];
  } else if (country === 'usa') {
    cities = ['New York', 'Los Angeles', 'Chicago'];
  } else if (country === 'ukr') {
    cities = ['Kyiv', 'Lviv',
