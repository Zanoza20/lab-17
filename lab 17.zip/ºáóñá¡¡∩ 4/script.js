function removeOption() {
  var select = document.getElementById('mySelect');
  select.remove(select.selectedIndex);
}

var button = document.getElementById('myButton');
button.addEventListener('click', removeOption);
