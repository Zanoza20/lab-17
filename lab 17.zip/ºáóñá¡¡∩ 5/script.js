var button = document.getElementById('myButton');
button.addEventListener('click', function() {
  console.log('I was pressed!');
});

button.addEventListener('mouseover', function() {
  console.log('Mouse on me!');
});

button.addEventListener('mouseout', function() {
  console.log('Mouse is not on me!');
});
